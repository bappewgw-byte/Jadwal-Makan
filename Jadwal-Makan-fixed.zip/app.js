// 1. Daftarkan Service Worker supaya bisa jalan offline & di HP
let swRegistration = null;
if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js')
        .then(reg => {
            swRegistration = reg;
            console.log('Service Worker berhasil didaftarkan!');
        })
        .catch(err => console.error('Service Worker gagal:', err));
}

const notifBtn = document.getElementById('enable-notif');
const testBtn = document.getElementById('test-notif');
const ICON = 'icons/icon-192.png';
const BADGE_ICON = 'icons/icon-notif.png';

// Jadwal makan: jam & pesan (24 jam format "HH:MM")
const SCHEDULE = [
    { time: '08:00', title: 'Waktunya Sarapan! 🍳', body: 'Telur rebus x2 + Ubi jalar oren rebus 180 gram' },
    { time: '10:30', title: 'Camilan Pagi (Opsional) ☕', body: 'Americano ice ATAU teh hijau' },
    { time: '13:00', title: 'Waktunya Makan Siang! 🍗', body: 'Nasi 4 sdm, Dada ayam, Tumis wortel' },
    { time: '15:00', title: 'Camilan Sore 🍎', body: 'Buah-buahan segar' },
    { time: '19:00', title: 'Waktunya Makan Malam! 🍜', body: 'Bihunku, Telur rebus, Brokoli rebus' }
];

// 2. Update tampilan tombol sesuai status izin notifikasi saat ini
function refreshNotifButton() {
    if (!('Notification' in window)) {
        notifBtn.textContent = '🔕 Browser tidak mendukung notifikasi';
        notifBtn.disabled = true;
        return;
    }
    if (Notification.permission === 'granted') {
        notifBtn.textContent = '✅ Pengingat Diet Aktif';
    } else if (Notification.permission === 'denied') {
        notifBtn.textContent = '🚫 Notifikasi Diblokir (buka Setelan Browser)';
    } else {
        notifBtn.textContent = '🔔 Aktifkan Pengingat Diet';
    }
}
refreshNotifButton();

// 3. Minta izin akses notifikasi ke user
// PENTING: kalau permission sudah pernah "denied", browser TIDAK akan
// menampilkan dialog izin lagi dan otomatis balikin "denied" tanpa nanya user.
// Makanya sebelumnya kelihatan kayak "kadang nolak sendiri" — padahal itu
// browser yang mengingat penolakan sebelumnya. Jadi kita kasih tau user
// harus buka setelan browser manual buat unblock-nya.
notifBtn.addEventListener('click', () => {
    if (!('Notification' in window)) return;

    if (Notification.permission === 'denied') {
        alert('Notifikasi diblokir di browser lu. Buka Setelan browser > Situs ini > Izin > Notifikasi, lalu ubah jadi "Izinkan". Setelah itu reload halaman ini.');
        return;
    }
    if (Notification.permission === 'granted') {
        alert('Pengingat diet lu udah aktif kok, gak perlu diaktifin lagi 👍');
        return;
    }

    Notification.requestPermission().then(permission => {
        refreshNotifButton();
        if (permission === 'granted') {
            alert('Mantap! Notifikasi diet lu udah aktif. Selama app ini kebuka (boleh di-minimize), reminder bakal muncul otomatis sesuai jadwal.');
            startScheduler();
        } else if (permission === 'denied') {
            alert('Yah, lu menolak notifikasi. Nanti jadwal dietnya kelewat lho. Kalau berubah pikiran, harus diaktifin manual lewat Setelan browser.');
        }
    });
});

// 4. Tombol buat ngetes langsung notifikasinya muncul atau kagak
testBtn.addEventListener('click', () => {
    if (Notification.permission !== 'granted') {
        alert('Aktifkan dulu tombol pengingat di atas, bro!');
        return;
    }
    showReminder('Waktunya Makan Siang! 🍗', 'Jangan lupa makan dada ayam panggang lu biar otot terjaga.');
});

// Fungsi utama buat munculin notifikasi (pakai service worker biar konsisten di HP)
function showReminder(title, body) {
    const options = {
        body,
        icon: ICON,
        badge: BADGE_ICON,
        vibrate: [200, 100, 200],
        tag: 'diet-reminder',
        renotify: true
    };
    if (swRegistration) {
        swRegistration.showNotification(title, options);
    } else if (navigator.serviceWorker) {
        navigator.serviceWorker.ready.then(reg => reg.showNotification(title, options));
    } else {
        new Notification(title, options);
    }
}

// 5. Scheduler: cek tiap menit apakah waktu sekarang cocok sama jadwal.
// Catatan: ini jalan selama halaman/app kebuka di background (browser tab
// atau app yang di-minimize). Kalau app-nya di-swipe close total, browser
// web biasa memang gak bisa kirim notifikasi terjadwal tanpa server push —
// itu batasan platform, bukan bug.
let lastFiredKey = null;
function checkSchedule() {
    if (Notification.permission !== 'granted') return;
    const now = new Date();
    const hh = String(now.getHours()).padStart(2, '0');
    const mm = String(now.getMinutes()).padStart(2, '0');
    const current = `${hh}:${mm}`;
    const todayKey = now.toDateString() + ' ' + current;

    const match = SCHEDULE.find(item => item.time === current);
    if (match && lastFiredKey !== todayKey) {
        lastFiredKey = todayKey;
        showReminder(match.title, match.body);
    }
}

let schedulerInterval = null;
function startScheduler() {
    if (schedulerInterval) return;
    checkSchedule();
    schedulerInterval = setInterval(checkSchedule, 20000); // cek tiap 20 detik
}

if (Notification.permission === 'granted') {
    startScheduler();
}
